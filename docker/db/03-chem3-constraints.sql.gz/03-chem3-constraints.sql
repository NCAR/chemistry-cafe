--
-- PostgreSQL database dump
--

-- Dumped from database version 10.23
-- Dumped by pg_dump version 10.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: atoms atoms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.atoms
    ADD CONSTRAINT atoms_pkey PRIMARY KEY (atomic_number);


--
-- Name: atoms atoms_symbol_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.atoms
    ADD CONSTRAINT atoms_symbol_key UNIQUE (symbol);


--
-- Name: branches branches_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_name_key UNIQUE (name);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: branchphotolysis branchphotolysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branchphotolysis
    ADD CONSTRAINT branchphotolysis_pkey PRIMARY KEY (id);


--
-- Name: branchreactions branchreactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branchreactions
    ADD CONSTRAINT branchreactions_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: externals externals_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externals
    ADD CONSTRAINT externals_name_key UNIQUE (name);


--
-- Name: externals externals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.externals
    ADD CONSTRAINT externals_pkey PRIMARY KEY (id);


--
-- Name: families families_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT families_id_key UNIQUE (id);


--
-- Name: families families_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT families_name_key UNIQUE (name);


--
-- Name: families families_ordering_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.families
    ADD CONSTRAINT families_ordering_key UNIQUE (ordering);


--
-- Name: log log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log
    ADD CONSTRAINT log_pkey PRIMARY KEY (id);


--
-- Name: micm_js micm_js_label_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.micm_js
    ADD CONSTRAINT micm_js_label_key UNIQUE (label);


--
-- Name: micm_js micm_js_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.micm_js
    ADD CONSTRAINT micm_js_pkey PRIMARY KEY (id);


--
-- Name: molecules molecules_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.molecules
    ADD CONSTRAINT molecules_id_key UNIQUE (id);


--
-- Name: molecules molecules_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.molecules
    ADD CONSTRAINT molecules_name_key UNIQUE (name);


--
-- Name: photolysis_groups photolysis_groups_order_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis_groups
    ADD CONSTRAINT photolysis_groups_order_key UNIQUE (ordering);


--
-- Name: photolysis_groups photolysis_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis_groups
    ADD CONSTRAINT photolysis_groups_pkey PRIMARY KEY (id);


--
-- Name: photolysis photolysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis
    ADD CONSTRAINT photolysis_pkey PRIMARY KEY (id);


--
-- Name: photolysis_rdiags photolysis_rdiags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis_rdiags
    ADD CONSTRAINT photolysis_rdiags_pkey PRIMARY KEY (id);


--
-- Name: photolysisproducts photolysisproducts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysisproducts
    ADD CONSTRAINT photolysisproducts_pkey PRIMARY KEY (photolysisproduct_id);


--
-- Name: rate_constant_function rate_constant_function_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_constant_function
    ADD CONSTRAINT rate_constant_function_id_key UNIQUE (id);


--
-- Name: rate_user_parameter rate_constant_parameter_rate_constant_parameter_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_user_parameter
    ADD CONSTRAINT rate_constant_parameter_rate_constant_parameter_id_key UNIQUE (rate_constant_parameter_id);


--
-- Name: rate_environmental_dependency rate_environmental_dependency_rate_environmental_dependency_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_environmental_dependency
    ADD CONSTRAINT rate_environmental_dependency_rate_environmental_dependency_key UNIQUE (rate_environmental_dependency_id);


--
-- Name: rdiags rdiags_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdiags
    ADD CONSTRAINT rdiags_name_key UNIQUE (name);


--
-- Name: rdiags rdiags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rdiags
    ADD CONSTRAINT rdiags_pkey PRIMARY KEY (id);


--
-- Name: reaction_groups reaction_groups_order_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reaction_groups
    ADD CONSTRAINT reaction_groups_order_key UNIQUE (ordering);


--
-- Name: reaction_groups reaction_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reaction_groups
    ADD CONSTRAINT reaction_groups_pkey PRIMARY KEY (id);


--
-- Name: reaction_rdiags reaction_rdiags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reaction_rdiags
    ADD CONSTRAINT reaction_rdiags_pkey PRIMARY KEY (id);


--
-- Name: reactions reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_pkey PRIMARY KEY (id);


--
-- Name: ref_files ref_files_label_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ref_files
    ADD CONSTRAINT ref_files_label_key UNIQUE (label);


--
-- Name: ref_files references_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ref_files
    ADD CONSTRAINT references_pkey PRIMARY KEY (id);


--
-- Name: sdiags sdiags_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sdiags
    ADD CONSTRAINT sdiags_name_key UNIQUE (name);


--
-- Name: sdiags sdiags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sdiags
    ADD CONSTRAINT sdiags_pkey PRIMARY KEY (id);


--
-- Name: suggestions suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggestions
    ADD CONSTRAINT suggestions_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tuv tub_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tuv
    ADD CONSTRAINT tub_id_key UNIQUE (id);


--
-- Name: users users_initials_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_initials_key UNIQUE (initials);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: wrf_custom_rates wrf_custom_rates_name_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wrf_custom_rates
    ADD CONSTRAINT wrf_custom_rates_name_version_key UNIQUE (name, version);


--
-- Name: wrf_custom_rates wrf_custom_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wrf_custom_rates
    ADD CONSTRAINT wrf_custom_rates_pkey PRIMARY KEY (id);


--
-- Name: wrf_photo_rates wrf_photo_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wrf_photo_rates
    ADD CONSTRAINT wrf_photo_rates_pkey PRIMARY KEY (id);


--
-- Name: branchphotolysis branchphotolysis_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branchphotolysis
    ADD CONSTRAINT branchphotolysis_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: branchphotolysis branchphotolysis_photolysis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branchphotolysis
    ADD CONSTRAINT branchphotolysis_photolysis_id_fkey FOREIGN KEY (photolysis_id) REFERENCES public.photolysis(id);


--
-- Name: branchreactions branchreactions_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branchreactions
    ADD CONSTRAINT branchreactions_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: branchreactions branchreactions_reaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branchreactions
    ADD CONSTRAINT branchreactions_reaction_id_fkey FOREIGN KEY (reaction_id) REFERENCES public.reactions(id);


--
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mechanism_externals mechanism_externals_external_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_externals
    ADD CONSTRAINT mechanism_externals_external_id_fkey FOREIGN KEY (external_id) REFERENCES public.externals(id);


--
-- Name: mechanism_externals mechanism_externals_mechanism_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_externals
    ADD CONSTRAINT mechanism_externals_mechanism_id_fkey FOREIGN KEY (mechanism_id) REFERENCES public.branches(id);


--
-- Name: mechanism_fixed mechanism_fixed_mechanism_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_fixed
    ADD CONSTRAINT mechanism_fixed_mechanism_id_fkey FOREIGN KEY (mechanism_id) REFERENCES public.branches(id);


--
-- Name: mechanism_fixed mechanism_fixed_species_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_fixed
    ADD CONSTRAINT mechanism_fixed_species_id_fkey FOREIGN KEY (species_id) REFERENCES public.molecules(id);


--
-- Name: mechanism_nottransported mechanism_nottransported_mechanism_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_nottransported
    ADD CONSTRAINT mechanism_nottransported_mechanism_id_fkey FOREIGN KEY (mechanism_id) REFERENCES public.branches(id);


--
-- Name: mechanism_nottransported mechanism_nottransported_species_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_nottransported
    ADD CONSTRAINT mechanism_nottransported_species_id_fkey FOREIGN KEY (species_id) REFERENCES public.molecules(id);


--
-- Name: mechanism_rdiags mechanism_rdiags_mechanism_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_rdiags
    ADD CONSTRAINT mechanism_rdiags_mechanism_id_fkey FOREIGN KEY (mechanism_id) REFERENCES public.branches(id);


--
-- Name: mechanism_rdiags mechanism_rdiags_rdiag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_rdiags
    ADD CONSTRAINT mechanism_rdiags_rdiag_id_fkey FOREIGN KEY (rdiag_id) REFERENCES public.rdiags(id);


--
-- Name: mechanism_sdiags mechanism_sdiags_mechanism_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_sdiags
    ADD CONSTRAINT mechanism_sdiags_mechanism_id_fkey FOREIGN KEY (mechanism_id) REFERENCES public.branches(id);


--
-- Name: mechanism_sdiags mechanism_sdiags_sdiag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_sdiags
    ADD CONSTRAINT mechanism_sdiags_sdiag_id_fkey FOREIGN KEY (sdiag_id) REFERENCES public.sdiags(id);


--
-- Name: mechanism_wrf_sdiags mechanism_wrf_sdiags_mechanism_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_wrf_sdiags
    ADD CONSTRAINT mechanism_wrf_sdiags_mechanism_id_fkey FOREIGN KEY (mechanism_id) REFERENCES public.branches(id);


--
-- Name: mechanism_wrf_sdiags mechanism_wrf_sdiags_sdiag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mechanism_wrf_sdiags
    ADD CONSTRAINT mechanism_wrf_sdiags_sdiag_id_fkey FOREIGN KEY (sdiag_id) REFERENCES public.sdiags(id);


--
-- Name: photolysis photolysis_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis
    ADD CONSTRAINT photolysis_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.photolysis_groups(id);


--
-- Name: photolysis photolysis_micm_js_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis
    ADD CONSTRAINT photolysis_micm_js_id_fkey FOREIGN KEY (micm_js_id) REFERENCES public.micm_js(id);


--
-- Name: photolysis photolysis_moleculename_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis
    ADD CONSTRAINT photolysis_moleculename_fkey FOREIGN KEY (moleculename) REFERENCES public.molecules(name);


--
-- Name: photolysis_rdiags photolysis_rdiags_photolysis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis_rdiags
    ADD CONSTRAINT photolysis_rdiags_photolysis_id_fkey FOREIGN KEY (photolysis_id) REFERENCES public.photolysis(id);


--
-- Name: photolysis_rdiags photolysis_rdiags_rdiags_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis_rdiags
    ADD CONSTRAINT photolysis_rdiags_rdiags_id_fkey FOREIGN KEY (rdiags_id) REFERENCES public.rdiags(id);


--
-- Name: photolysis_references photolysis_references_photolysis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis_references
    ADD CONSTRAINT photolysis_references_photolysis_id_fkey FOREIGN KEY (photolysis_id) REFERENCES public.photolysis(id);


--
-- Name: photolysis_references photolysis_references_reference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis_references
    ADD CONSTRAINT photolysis_references_reference_id_fkey FOREIGN KEY (reference_id) REFERENCES public.ref_files(id);


--
-- Name: photolysis photolysis_wrf_photo_rates_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis
    ADD CONSTRAINT photolysis_wrf_photo_rates_id_fkey FOREIGN KEY (wrf_photo_rates_id) REFERENCES public.wrf_photo_rates(id);


--
-- Name: photolysiscomments photolysiscomments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysiscomments
    ADD CONSTRAINT photolysiscomments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(id);


--
-- Name: photolysiscomments photolysiscomments_photolysis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysiscomments
    ADD CONSTRAINT photolysiscomments_photolysis_id_fkey FOREIGN KEY (photolysis_id) REFERENCES public.photolysis(id);


--
-- Name: photolysisproducts photolysisproducts_photolysisid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysisproducts
    ADD CONSTRAINT photolysisproducts_photolysisid_fkey FOREIGN KEY (photolysisid) REFERENCES public.photolysis(id);


--
-- Name: rate_cross_environment rate_cross_environment_rate_constant_function_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_cross_environment
    ADD CONSTRAINT rate_cross_environment_rate_constant_function_id_fkey FOREIGN KEY (rate_constant_function_id) REFERENCES public.rate_constant_function(id);


--
-- Name: rate_cross_environment rate_cross_environment_rate_environmental_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_cross_environment
    ADD CONSTRAINT rate_cross_environment_rate_environmental_id_fkey FOREIGN KEY (rate_environmental_id) REFERENCES public.rate_environmental_dependency(rate_environmental_dependency_id);


--
-- Name: rate_cross_parameters rate_cross_parameters_rate_function_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_cross_parameters
    ADD CONSTRAINT rate_cross_parameters_rate_function_id_fkey FOREIGN KEY (rate_function_id) REFERENCES public.rate_constant_function(id);


--
-- Name: rate_cross_parameters rate_cross_parameters_rate_parameters_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_cross_parameters
    ADD CONSTRAINT rate_cross_parameters_rate_parameters_id_fkey FOREIGN KEY (rate_parameters_id) REFERENCES public.rate_user_parameter(rate_constant_parameter_id);


--
-- Name: reaction_rdiags reaction_rdiags_rdiags_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reaction_rdiags
    ADD CONSTRAINT reaction_rdiags_rdiags_id_fkey FOREIGN KEY (rdiags_id) REFERENCES public.rdiags(id);


--
-- Name: reaction_rdiags reaction_rdiags_reaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reaction_rdiags
    ADD CONSTRAINT reaction_rdiags_reaction_id_fkey FOREIGN KEY (reaction_id) REFERENCES public.reactions(id);


--
-- Name: reactioncomments reactioncomments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactioncomments
    ADD CONSTRAINT reactioncomments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(id);


--
-- Name: reactioncomments reactioncomments_reaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactioncomments
    ADD CONSTRAINT reactioncomments_reaction_id_fkey FOREIGN KEY (reaction_id) REFERENCES public.reactions(id);


--
-- Name: reactionproducts reactionproducts_reactionid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactionproducts
    ADD CONSTRAINT reactionproducts_reactionid_fkey FOREIGN KEY (reaction_id) REFERENCES public.reactions(id);


--
-- Name: reactionreactants reactionreactants_reactionid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactionreactants
    ADD CONSTRAINT reactionreactants_reactionid_fkey FOREIGN KEY (reaction_id) REFERENCES public.reactions(id);


--
-- Name: reactions reactions_rate_constant_function_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_rate_constant_function_id_fkey FOREIGN KEY (rate_constant_function_id) REFERENCES public.rate_constant_function(id);


--
-- Name: reactions reactions_reaction_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_reaction_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.reaction_groups(id);


--
-- Name: reactions reactions_wrf_custom_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_wrf_custom_rate_id_fkey FOREIGN KEY (wrf_custom_rate_id) REFERENCES public.wrf_custom_rates(id);


--
-- Name: ref_files references_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ref_files
    ADD CONSTRAINT references_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sdiags sdiags_family_id2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sdiags
    ADD CONSTRAINT sdiags_family_id2_fkey FOREIGN KEY (family_id2) REFERENCES public.families(id);


--
-- Name: sdiags sdiags_family_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sdiags
    ADD CONSTRAINT sdiags_family_id_fkey FOREIGN KEY (family_id) REFERENCES public.families(id);


--
-- Name: sdiags sdiags_species_id2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sdiags
    ADD CONSTRAINT sdiags_species_id2_fkey FOREIGN KEY (species_id2) REFERENCES public.molecules(id);


--
-- Name: sdiags sdiags_species_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sdiags
    ADD CONSTRAINT sdiags_species_id_fkey FOREIGN KEY (species_id) REFERENCES public.molecules(id);


--
-- Name: species_externals species_externals_external_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.species_externals
    ADD CONSTRAINT species_externals_external_id_fkey FOREIGN KEY (external_id) REFERENCES public.externals(id);


--
-- Name: species_externals species_externals_species_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.species_externals
    ADD CONSTRAINT species_externals_species_id_fkey FOREIGN KEY (species_id) REFERENCES public.molecules(id);


--
-- Name: species_families species_families_families_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.species_families
    ADD CONSTRAINT species_families_families_id_fkey FOREIGN KEY (families_id) REFERENCES public.families(id);


--
-- Name: species_families species_families_species_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.species_families
    ADD CONSTRAINT species_families_species_id_fkey FOREIGN KEY (species_id) REFERENCES public.molecules(id);


--
-- Name: suggestions suggestions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggestions
    ADD CONSTRAINT suggestions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tag_comments tag_comment_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag_comments
    ADD CONSTRAINT tag_comment_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(id);


--
-- Name: tag_comments tag_comment_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag_comments
    ADD CONSTRAINT tag_comment_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: tag_photolysis tag_photolysis_photolysis_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag_photolysis
    ADD CONSTRAINT tag_photolysis_photolysis_id_fkey FOREIGN KEY (photolysis_id) REFERENCES public.photolysis(id);


--
-- Name: tag_photolysis tag_photolysis_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag_photolysis
    ADD CONSTRAINT tag_photolysis_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: tag_reactions tag_reaction_reaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag_reactions
    ADD CONSTRAINT tag_reaction_reaction_id_fkey FOREIGN KEY (reaction_id) REFERENCES public.reactions(id);


--
-- Name: tag_reactions tag_reaction_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag_reactions
    ADD CONSTRAINT tag_reaction_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: tags tags_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id);


--
-- Name: tags tags_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_creator_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: photolysis tuv_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photolysis
    ADD CONSTRAINT tuv_id_fkey FOREIGN KEY (tuv_id) REFERENCES public.tuv(id);


--
-- PostgreSQL database dump complete
--

